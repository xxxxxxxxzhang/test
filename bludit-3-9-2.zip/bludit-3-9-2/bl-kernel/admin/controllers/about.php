<?php defined('BLUDIT') or die('Bludit CMS.');

// Title of the page
$layout['title'] = $L->g('About') . ' - ' . $layout['title'];