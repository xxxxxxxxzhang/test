<!-- Check if the user is logged -->

<!-- DEBUG: Each request increase the count of simple stats -->

<!-- <script>
	setInterval(
		function() {
			var ajax = new bluditAjax();
			ajax.userLogged(showAlert);
		}, 15000);
</script> -->
