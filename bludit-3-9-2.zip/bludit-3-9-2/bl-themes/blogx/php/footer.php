<footer class="footer bg-dark">
	<div class="container">
		<p class="m-0 text-center text-white text-uppercase"><?php echo $site->footer(); ?><span class="ml-5 text-warning">Powered by<img class="mini-logo" src="<?php echo DOMAIN_THEME_IMG.'favicon.png'; ?>"/><a target="_blank" class="text-white" href="https://www.bludit.com">和飞信</a></span></p>
	</div>
</footer>